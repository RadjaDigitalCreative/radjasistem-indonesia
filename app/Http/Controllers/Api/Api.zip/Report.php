<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use App\Http\Controllers\Api\Exports\LabaExport;
use App\Http\Controllers\Api\Exports\ReportExport;
use Maatwebsite\Excel\Facades\Excel;


class Report extends Controller
{
	public function report_export()
	{
		return Excel::download(new ReportExport, 'report_orders.xlsx');
	}
	public function export()
	{
		return Excel::download(new LabaExport, 'laba.xlsx');
	}
	public function grade()
	{  
		$data   =  DB::table('terjual')
		->join('products', 'terjual.product_id', '=', 'products.id') 
		->where('terjual.keperluan', '=', 'Penjualan') 
		->select(
			'terjual.id',
			'terjual.name AS nama_barang',
			'terjual.cabang',
			'terjual.terjual',
		)
		->get();
		return response()->json([
			'report grade pesananan' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);

	}
	public function laba()
	{    
		$data   =  DB::table('products')
		->join('order_details', function($join){
			$join->on('products.name', '=', 'order_details.product_name');
		})
		->join('orders', function($join){
			$join->on('orders.id', '=', 'order_details.order_id');
		})
		->select(
			'products.name',
			'products.purchase_price',
			'products.price',
			'order_details.quantity',
			'orders.lokasi',
			'orders.name AS customer',
			'orders.created_at',

		)
		->get(); 
		return response()->json([
			'report laba' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);
	}

	public function index()
	{
		$data = DB::table('orders')
		->join('users', 'users.id', '=', 'orders.created_by') 
		->join('payments', 'payments.id', '=', 'orders.payment_id') 
		->join('order_details', 'orders.id', '=', 'order_details.order_id') 
		->where('orders.keperluan', '=', 'Penjualan') 
		->select(
			'orders.id',
			'orders.table_number',
			'orders.discount',
			'orders.total',
			'orders.keperluan',
			'orders.image',
			'payments.name as payment name',
			'users.name',
			'orders.lokasi',
		)
		->selectRaw('orders.lokasi as ami')
		->get();

		return response()->json([
			'report order' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);

	}
	public function edit($id)
	{
		$data = DB::table('orders')
		->join('users', 'users.id', '=', 'orders.created_by') 
		->where('orders.id', '=', $id) 
		->where('orders.keperluan', '=', 'Penjualan') 
		->select(
			'orders.id',
			'orders.table_number',
			'orders.discount',
			'orders.total',
			'orders.keperluan',
			'orders.image',
			'orders.payment_id',
			'users.name',
			'orders.lokasi',
		)
		->get();
		$terjual = DB::table ('terjual')
		->join('products', function($join){
			$join->on('products.name', '=', 'terjual.name')
			->on('products.lokasi', '=', 'terjual.cabang');
		})
		->orderBy('terjual.terjual', 'desc')
		->get();
		return response()->json([
			'report order' => $data,
			'grade' => $terjual,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);


	}
	public function create(Request $request)
	{
		$data = DB::table('orders')
		->insert($request->all());
		return response()->json([
			'report' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 201);
	}
	public function update(Request $request, $id)
	{
		$data = DB::table('orders')
		->where('id', $id)
		->update($request->all());
		if (is_null($data)) {
			return response()->json('data tidak ada', 404);
		}else{
			return response()->json([
				'report' => $data,
				'status_code'   => 200,
				'msg'           => 'success',
			], 200);
		}
	}
	public function delete(Request $request, $id)
	{
		$data = DB::table('orders')
		->where('id', $id)
		->delete();
		return response()->json([
			'orders' => 'Data Berhasil Dihapus',
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);

	}
}

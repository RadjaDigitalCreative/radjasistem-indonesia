<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\User;
use DB;


class Login extends Controller
{

	public function user_id($id)
	{
		$data = DB::table('users')->where('id', $id)->get();
		return response()->json([
			'user' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);
	}
	public function login(Request $request)
	{
		$credentials = $request->only('email', 'password');
		if (Auth::attempt($credentials)) {
			$data = DB::table('users')
			->where('email' ,'=' , $credentials)
			->get();
			return response()->json([
				'username' => $data,
				'status_code'   => 200,
				'msg'           => 'success',
			], 200);
		}else{
			return response()->json([
				'username' => 'tidak ditemukan',
				'status_code'   => 200,
				'msg'           => 'not found',
			], 200);
		}
	}
	public function register(Request $request){
		$data = new User;
		$data->name = $request->name;
		$data->email = $request->email;
		$data->lokasi = $request->lokasi;
		$data->notelp = $request->notelp;
		$data->level = 'Owner';
		$data->password = Hash::make($request->password);
		$data->id_team = bin2hex(random_bytes(20));
		$data->save();
		if ($data['level'] == 'Owner') {
			DB::table('role')
			->insert([
				'user_id'  =>  $data['id'],
				'is_admin' => 1,
				'is_akses' => 1,
				'is_supplier' => 1,
				'is_kategori' => 1,
				'is_produk' => 1,
				'is_order' => 1,
				'is_pay' => 1,
				'is_report' => 1,
				'is_kas' => 1,
				'is_stok' => 1,
				'is_cabang' => 1,
				'is_user' => 1
			]);
		}
		else{
			DB::table('role')
			->insert([
				'user_id'  =>  $data['id'],
			]);
		}
		DB::table('role_cabang')
		->insert([
			'user_id'  =>  $data['id'],
		]);
		DB::table('role_payment')
		->insert([
			'user_id' =>  $data['id'],
			'pay' =>  2,
			'dibayar' => date('Y-m-d', strtotime('+93 days', strtotime(now())))
		]);
		return response()->json([
			'cabang' => $data,
			'status_code'   => 200,
			'msg'           => 'Berhasil Registrasi',
		], 201);
	}
	public function user()
	{
		$data = DB::table('users')->get();
		return response()->json([
			'users' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);

	}
}

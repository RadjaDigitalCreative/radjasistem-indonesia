<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
// use app\Exceptions\Handler;
use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class Absensi extends Controller
{
    public function absensi_lembur(Request $request){  
        $jam_lembur = DB::table('gaji_lembur')
        ->leftJoin('users', function($join){
            $join->on('gaji_lembur.id_team', '=', 'users.id_team');
        })
        ->where('users.id', $request->user_id)
        ->first();

        $time = Carbon::parse($jam_lembur->jam_masuk_lembur)->format('H');
        $ami = now()->format('H');
        $lembur = $ami - $time;

        $user = DB::table('kerja')
        ->where('user_id', $request->user_id)
        ->where('date', $request->date)
        ->first();
        if ($user === null) {
            return response()->json([
                'absen lembur' => 'Absen lembur tidak berhasil',
                'status_code'   => 200,
                'msg'           => 'success',
            ], 200);
        }else{
            $data = DB::table('kerja')
            ->where('user_id', $request->user_id)
            ->where('date', $request->date)
            ->update([
                'lembur' => $lembur,
                'lembur_at' => now()->toTimeString(),
            ]);
            return response()->json([
                'absen lembur' => $data,
                'status_code'   => 200,
                'msg'           => 'success',
            ], 200); 
        }
    }
    public function index(Request $request)
    {
        $data = DB::table('absensi')
        ->select([
            'absensi.id',
            'absensi.date',
            'absensi.bulan',
            'absensi.id_team',
            'absensi.created_at AS absen_masuk',
            'absensi.updated_at AS absen_keluar',
        ])
        ->where('absensi.id_team', $request->id_team)
        ->get();
        return response()->json([
            'hari absen' => $data,
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);
    }

    public function kirim(Request $request)
    {
        $time = Carbon::now()->toTimeString();
        $user = DB::table('kerja')
        ->where('user_id', $request->user_id)
        ->where('date', $request->date)
        ->first();

        $telat = DB::table('users')
        ->leftJoin('kerja', function($join){
            $join->on('kerja.user_id', '=', 'users.id');
        })
        ->leftJoin('jam_kerja', function($join){
            $join->on('jam_kerja.id_team', '=', 'users.id_team');
        })
        ->where('users.id', $request->user_id)
        ->first();

        if ($time >= $telat->jam_masuk) {
            if ($user === null) {
                $data = DB::table('kerja')
                ->insert([
                    'date' => $request->date,
                    'bulan' => $request->bulan,
                    'user_id' => $request->user_id,
                    'status' => 1,
                    'created_at' =>now(),
                    'absen' => $time,
                    'absen_telat' => 1,
                ]);
                return response()->json([
                    'absen masuk' => $data,
                    'status_code'   => 200,
                    'msg'           => 'success',
                ], 200);
            }else{
                $data = DB::table('kerja')
                ->where('date', $request->date)
                ->update([
                    'date' => $request->date,
                    'bulan' => $request->bulan,
                    'user_id' => $request->user_id,
                    'status' => 2,
                    'updated_at' =>now(),
                ]);
                return response()->json([
                    'absen keluar' => $data,
                    'status_code'   => 200,
                    'msg'           => 'success',
                ], 200);
            }        
        }elseif($time <= $telat->jam_masuk){
            if ($user === null) {
               $data = DB::table('kerja')
               ->insert([
                'date' => $request->date,
                'bulan' => $request->bulan,
                'user_id' => $request->user_id,
                'status' => 1,
                'created_at' =>now(),
                'absen' => $time,
            ]);
               return response()->json([
                'absen masuk' => $data,
                'status_code'   => 200,
                'msg'           => 'success',
            ], 200);
           }else{
               $data = DB::table('kerja')
               ->where('date', $request->date)
               ->update([
                'date' => $request->date,
                'bulan' => $request->bulan,
                'user_id' => $request->user_id,
                'status' => 2,
                'updated_at' =>now(),
            ]);
               return response()->json([
                'absen keluar' => $data,
                'status_code'   => 200,
                'msg'           => 'success',
            ], 200);
           }      
       }
   }
   public function sudah_absen(Request $request)
   {
    $data = DB::table('absensi')
    ->join('users', function($join){
        $join->on('users.id_team', '=', 'absensi.id_team');
    })
    ->join('kerja', function($join){
        $join->on('kerja.date', '=', 'absensi.date');
    })
    ->select([
        'absensi.id',
        'absensi.date',
        'absensi.bulan',
        'absensi.id_team',
        'kerja.status',
        'kerja.user_id',
        'kerja.lembur',
        'kerja.absen',
        'absensi.created_at AS absen_masuk',
        'absensi.updated_at AS absen_keluar',
        'kerja.lembur_at',
        'kerja.absen_telat',
    ])
    ->where('users.id_team', $request->id_team)
    ->get();
    return response()->json([
        'sudah absen' => $data,
        'status_code'   => 200,
        'msg'           => 'success',
    ], 200);
}

}
